# Brayne Cookie Consent

**Version:** 1.3.0  
**Author:** Brayne Digital  
**Website:** [https://braynedigital.com/](https://braynedigital.com/)  
**Contact:** support@braynedigital.com  
**License:** GPL v2 or later

## Description

A professional, lightweight cookie consent banner for WordPress websites with **ADVANCED STYLING OPTIONS**. Perfect for GDPR and cookie law compliance. Full customization control - change colors, fonts, buttons, and more from the admin panel. Works on any WordPress site with zero coding required!

## ✨ Features

### Core Features
✅ **Lightweight** - No external dependencies, minimal code  
✅ **GDPR Compliant** - Proper cookie consent implementation  
✅ **Mobile Responsive** - Perfect on all devices  
✅ **Easy Setup** - Works instantly with sensible defaults  
✅ **Privacy Policy Integration** - Auto-links to your policy page  
✅ **Cookie Management** - Remembers user choice (customizable duration)  
✅ **Accept/Decline Options** - Let users choose  
✅ **Smooth Animations** - Professional slide effects  

### 🎨 Advanced Styling Options (NEW!)

#### Banner Customization
- **Position** - Top or Bottom of page
- **Background Color** - Any color you want
- **Border Color & Width** - Fully customizable
- **Drop Shadow** - Enable/disable shadow effect

#### Typography Control
- **Font Family** - Choose from 12+ fonts or inherit from theme
  - Arial, Helvetica, Georgia, Times New Roman
  - Verdana, Trebuchet MS, System Font, and more
- **Title Styling** - Color and font size
- **Text Styling** - Color and font size  
- **Link Styling** - Color and hover color

#### Button Customization
- **Border Radius** - From square (0) to pill-shaped (50)
- **Font Size** - 10-30px
- **Font Weight** - Light to Extra Bold
- **Padding** - Vertical and horizontal
- **Accept Button Colors**:
  - Background color
  - Text color
  - Hover background color
  - Hover text color
- **Decline Button Colors**:
  - Background color
  - Text color
  - Hover background color
  - Hover text color

### Admin Settings Interface
- **Organized Tabs** - Content, Banner Style, Typography, Buttons
- **Color Pickers** - Visual color selection (no hex codes needed)
- **Live Previews** - See changes immediately
- **Smart Defaults** - Professional look out of the box

## Installation

### Method 1: Upload via WordPress Admin
1. Download/zip the plugin folder
2. Go to **Plugins → Add New → Upload Plugin**
3. Upload the `brayne-cookie-consent.zip` file
4. Click **Install Now** and then **Activate**

### Method 2: Manual Installation
1. Upload the `brayne-cookie-consent` folder to `/wp-content/plugins/`
2. Go to **Plugins** in WordPress admin
3. Find **Brayne Cookie Consent** and click **Activate**

### Method 3: FTP Upload
1. Upload the entire `brayne-cookie-consent` folder to `/wp-content/plugins/`
2. Activate through the **Plugins** menu in WordPress

## Configuration

### Quick Start
1. Activate the plugin
2. The banner will work immediately with default settings
3. (Optional) Go to **Settings → Cookie Consent** to customize

### Settings Overview

#### **Content Tab**
- Banner title and text
- Accept/Decline button labels
- Toggle decline button on/off
- Cookie duration (days)

#### **Banner Style Tab**
- Position (top/bottom)
- Background color
- Border color and width
- Drop shadow on/off

#### **Typography Tab**
- Font family selection
- Title color and size
- Text color and size
- Link colors (normal and hover)

#### **Buttons Tab**
- General button styling (radius, size, weight, padding)
- Accept button colors (4 options)
- Decline button colors (4 options)

## 🎨 Styling Examples

### Example 1: Modern Blue Theme
```
Banner Position: Bottom
Background: #ffffff
Border: #007BFF (3px)
Font: System Font

Title: #1a1a1a (18px)
Text: #333333 (14px)

Accept Button:
- Background: #007BFF
- Text: #ffffff
- Hover BG: #0056b3
- Radius: 25px (pill shape)

Decline Button:
- Background: #f8f9fa
- Text: #6c757d
```

### Example 2: Elegant Dark Theme
```
Banner Position: Top
Background: #2c3e50
Border: #e74c3c (2px)
Font: Georgia, serif

Title: #ecf0f1 (20px)
Text: #bdc3c7 (15px)
Links: #e74c3c

Accept Button:
- Background: #e74c3c
- Text: #ffffff
- Hover BG: #c0392b
- Radius: 5px
```

### Example 3: Minimal Clean
```
Banner Position: Bottom
Background: #fafafa
Border: #000000 (1px)
Font: Helvetica
Shadow: No

Title: #000000 (16px)
Text: #555555 (13px)

Accept Button:
- Background: #000000
- Text: #ffffff
- Radius: 0px (square)
- Padding: 15px 40px

Decline Button: Hidden
```

## Usage

### Testing the Banner
To see the banner after accepting:
1. Clear browser cookies (Ctrl+Shift+Delete)
2. Open incognito/private window
3. Use different browser

### Customization Workflow
1. **Start with Content** - Set your text and messages
2. **Style the Banner** - Choose position, colors
3. **Adjust Typography** - Pick fonts and sizes
4. **Perfect the Buttons** - Match your brand colors
5. **Test** - View in incognito mode

### Brand Color Matching
Use the color pickers to match your brand:
- Upload your logo to an online color picker tool
- Extract hex codes from your brand guidelines
- Use browser DevTools to get colors from your site

## Privacy Policy

Ensure you have a Privacy Policy page:
1. Go to **Settings → Privacy** in WordPress
2. Select or create your Privacy Policy page
3. The plugin automatically links to it

## Frequently Asked Questions

**Q: Can I customize everything?**  
A: Yes! Colors, fonts, sizes, positions, borders - everything is customizable.

**Q: Do I need coding knowledge?**  
A: No! Everything is done through the admin interface with visual controls.

**Q: Will it match my theme?**  
A: Yes! You can match any color scheme, or set Font Family to "Inherit" to use your theme's font.

**Q: Can I hide the decline button?**  
A: Yes! Toggle it off in Content settings.

**Q: What fonts are available?**  
A: 12+ fonts including Arial, Helvetica, Georgia, Times New Roman, Verdana, System Font, and more. Or inherit from your theme.

**Q: Does it slow down my site?**  
A: No! Lightweight with inline CSS/JS, no external files loaded.

**Q: Can I change the position to top?**  
A: Yes! Banner Style tab → Position → Top

**Q: Can I make rounded buttons?**  
A: Yes! Increase Border Radius (50px for pill shape, 0px for square)

**Q: Does it work with page builders?**  
A: Yes! Works with Elementor, Beaver Builder, Divi, and all others.

**Q: Can I use it on multiple sites?**  
A: Yes! It's a portable plugin - use on unlimited sites.

## Compatibility

- **WordPress:** 5.0 or higher
- **PHP:** 7.0 or higher
- **Browsers:** All modern browsers
- **Works with:** All themes, WooCommerce, Elementor, page builders
- **Mobile:** Fully responsive
- **GDPR:** Compliant

## Changelog

### Version 1.1.0
- ✨ **NEW:** Advanced styling options
- ✨ **NEW:** Font family selection (12+ fonts)
- ✨ **NEW:** Complete typography control
- ✨ **NEW:** Advanced button customization
- ✨ **NEW:** Banner position (top/bottom)
- ✨ **NEW:** Background color customization
- ✨ **NEW:** Border width and color controls
- ✨ **NEW:** Optional drop shadow
- ✨ **NEW:** Organized tabbed admin interface
- ✨ **NEW:** Accept button color controls (4 options)
- ✨ **NEW:** Decline button color controls (4 options)
- ✨ **NEW:** Button radius, padding, font weight
- ✨ **NEW:** Link color and hover color
- 🎨 Enhanced admin interface with tabs
- 🎨 Visual color pickers for all color options
- 📝 Better organized settings
- 🚀 Improved performance

### Version 1.0.0
- Initial release
- Basic cookie consent banner
- Accept/Decline buttons
- Simple customization options
- Admin settings page
- Privacy policy integration
- Mobile responsive design
- Smooth animations

## Support

For support, customization requests, or bug reports:
- **Email:** support@braynedigital.com
- **Website:** [https://braynedigital.com/](https://braynedigital.com/)

## Pro Tips

1. **Match Your Brand** - Use your brand colors for maximum consistency
2. **Test on Mobile** - Make sure it looks good on all devices
3. **Keep it Simple** - Don't overcomplicate the message
4. **Use System Font** - For the cleanest, fastest loading option
5. **A/B Test** - Try different colors to see what gets more acceptances
6. **Readable Text** - Ensure good contrast between text and background
7. **Clear Buttons** - Make accept button stand out visually

## Credits

Developed with ❤️ by **Brayne** team.  
Designed for easy use and maximum flexibility.

## License

This plugin is licensed under the GPL v2 or later.

```
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
```

---

**Transform your cookie consent banner to match your brand perfectly! 🎨🍪**
